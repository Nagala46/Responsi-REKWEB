<div class="row">
	<div class="col m 12">
		<center>
			<h5>Selamat Datang Di Sistem Perpustakaan Online</h5>
		</center><hr>
	</div>

	<div class="row">
		<div class="col m12">
			<div class="card-panel teal darken-2 center white-text">
				<p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusamus qui iure, inventore repudiandae dolor velit. Tempore, magni possimus officia nobis quam voluptatem fuga officiis aliquam molestiae, quas corrupti necessitatibus consectetur libero doloremque! Quod corporis eaque, eveniet qui distinctio omnis reprehenderit excepturi sunt praesentium aliquam repellat similique doloremque animi dolorem ullam.
				</p>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col m6 s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img src="<?php echo base_url(); ?>assets2/img/bb.jpg"> <!-- random image -->
				</div>
				<div class="card-content teal center">
                    <a class="btn" href="<?php echo base_url();?>Buku/profile">Daftar Buku</a>
				</div>
			</div>
		</div>

        <div class="col m6 s12">
			<div class="card">
				<div class="card-image waves-effect waves-block waves-light">
					<img src="<?php echo base_url(); ?>assets2/img/BG.jpg"> <!-- random image -->
				</div>
				<div class="card-content teal center">
                    <a class="btn" href="<?php echo base_url();?>Buku/list_buku">Tentang Perpustakaan</a>
				</div>
			</div>
		</div>
	</div>

</div>
</div>
