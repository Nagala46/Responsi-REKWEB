<div class="row">
	<div class="col m 12">
		<h5>Sistem Perpustakaan Online</h5>
	</div>
</div>

<div class="row">
	<div class="col m6">
		<div class="card-panel teal darken-2 white-text">
			<h6><b>Visi</b></h6>
			<p>
				Lorem, ipsum dolor sit amet consectetur adipisicing elit. Magni natus est, iste quae at deleniti, animi
				maiores minus explicabo corporis cupiditate, reiciendis non facilis quasi assumenda laudantium. Ab,
				molestiae odio!
			</p><br>
			<h6><b>Misi</b></h6>
			<li>
				Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vero, dolore.
			</li>
			<li>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid magnam assumenda ipsa praesentium.
			</li>
			<li>
				Lorem ipsum dolor sit amet consectetur adipisicing elit.
			</li>
			<li>
				Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa, deleniti distinctio.
			</li>
		</div>
	</div>
    <div class="col m6">
        <div class="card-panel teal darken-2 white-text">
            <h6><b>Identitas Perpustakaan</b></h6><hr>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum eveniet quod atque animi architecto ad distinctio, magnam eaque non dicta commodi omnis reiciendis libero quaerat vel saepe suscipit voluptate excepturi fuga voluptatibus ut. Molestiae atque quis in rem omnis reiciendis facilis necessitatibus, enim inventore libero provident perferendis eius impedit nostrum magni voluptatem quia tempore nobis ipsum excepturi consequatur adipisci sequi repellat tenetur! Nam dolores perferendis, culpa beatae accusantium nemo, nostrum laboriosam quidem eos aspernatur saepe delectus atque iure, voluptatibus id officiis voluptatem fuga nesciunt. Beatae harum sint pariatur.
            </p>
        </div>
    </div>
</div>
